import os
import django

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "config.settings")
django.setup()

from django.contrib.auth import get_user_model
from apps.catalog.models import Location, Category, Vendor, EquipmentItem
from apps.clients.models import Client
from apps.orders.models import Order

User = get_user_model()

def seed():
    print("--- Заполнение начальными данными строго по PDF ---")

    # 1. Создание пользователей
    admin_user, _ = User.objects.get_or_create(
        username="admin",
        defaults={
            "email": "admin@example.com",
            "full_name": "Администратор Системы",
            "role": User.Role.ADMIN,
            "position": "Главный администратор",
            "is_staff": True,
            "is_superuser": True,
        }
    )
    admin_user.set_password("admin123")
    admin_user.save()

    ivanov, _ = User.objects.get_or_create(
        username="ivanov",
        defaults={
            "email": "ivanov@company.ru",
            "full_name": "Иванов И. И.",
            "role": User.Role.SPECIALIST,
            "position": "Инженер технической поддержки",
            "is_staff": True,
        }
    )
    ivanov.set_password("password123")
    ivanov.save()

    petrov, _ = User.objects.get_or_create(
        username="petrov",
        defaults={
            "email": "petrov@company.ru",
            "full_name": "Петров П. П.",
            "role": User.Role.SPECIALIST,
            "position": "Специалист 1-й линии поддержки",
            "is_staff": True,
        }
    )
    petrov.set_password("password123")
    petrov.save()

    sidorov, _ = User.objects.get_or_create(
        username="sidorov",
        defaults={
            "email": "sidorov@company.ru",
            "full_name": "Сидоров С. С.",
            "role": User.Role.SPECIALIST,
            "position": "Системный администратор",
            "is_staff": True,
        }
    )
    sidorov.set_password("password123")
    sidorov.save()

    print("Пользователи созданы: admin, ivanov, petrov, sidorov")

    # 2. Локации
    loc205, _ = Location.objects.get_or_create(name="Аудитория 205")
    loc101, _ = Location.objects.get_or_create(name="Аудитория 101")
    Location.objects.get_or_create(name="Серверная")
    Location.objects.get_or_create(name="Бухгалтерия")
    Location.objects.get_or_create(name="Деканат")

    # 3. Категории строго по слайду 3 ПР2/ПР5
    cat_eq, _ = Category.objects.get_or_create(name="Оборудование", defaults={"description": "Принтеры, мониторы, ПК", "sla_hours": 4})
    cat_acc, _ = Category.objects.get_or_create(name="Учётные записи", defaults={"description": "Логины, пароли, доступы", "sla_hours": 2})
    cat_sw, _ = Category.objects.get_or_create(name="ПО", defaults={"description": "Установка и сбои ПО", "sla_hours": 8})
    cat_net, _ = Category.objects.get_or_create(name="Сеть", defaults={"description": "Wi-Fi, локальная сеть, интернет", "sla_hours": 4})

    # 4. Производители
    hp, _ = Vendor.objects.get_or_create(name="HP", defaults={"country": "США"})
    dell, _ = Vendor.objects.get_or_create(name="Dell", defaults={"country": "США"})
    cisco, _ = Vendor.objects.get_or_create(name="Cisco", defaults={"country": "США"})

    # 5. Оборудование
    printer, _ = EquipmentItem.objects.get_or_create(
        inventory_number="PRN-HP-205",
        defaults={
            "name": "Лазерный принтер LaserJet 1020",
            "vendor": hp,
            "category": cat_eq,
            "status": EquipmentItem.Status.OPERATIONAL,
        }
    )
    pc, _ = EquipmentItem.objects.get_or_create(
        inventory_number="PC-DELL-101",
        defaults={
            "name": "Компьютер преподавателя OptiPlex",
            "vendor": dell,
            "category": cat_eq,
            "status": EquipmentItem.Status.OPERATIONAL,
        }
    )
    router, _ = EquipmentItem.objects.get_or_create(
        inventory_number="NET-CISCO-GW",
        defaults={
            "name": "Точка доступа Wi-Fi 802.11ax",
            "vendor": cisco,
            "category": cat_net,
            "status": EquipmentItem.Status.OPERATIONAL,
        }
    )

    # 6. Заявители (Клиенты)
    client1, _ = Client.objects.get_or_create(
        phone="+7 (999) 111-22-33",
        defaults={
            "full_name": "Смирнова Елена Викторовна",
            "email": "smirnova@college.edu",
            "department": "Кафедра ИТ (ауд. 205)",
            "manager": ivanov,
        }
    )
    client2, _ = Client.objects.get_or_create(
        phone="+7 (999) 222-33-44",
        defaults={
            "full_name": "Васильев Андрей Сергеевич",
            "email": "vasiliev@college.edu",
            "department": "Учебная часть",
            "manager": petrov,
        }
    )
    client3, _ = Client.objects.get_or_create(
        phone="+7 (999) 333-44-55",
        defaults={
            "full_name": "Николаева Ольга Павловна",
            "email": "nikolaeva@college.edu",
            "department": "Библиотека / Медиатека",
            "manager": sidorov,
        }
    )

    # 7. Заявки ровно по слайдам PDF (слайд 3 ПР2 и слайд 3 ПР5)
    tickets_data = [
        {
            "title": "Не работает принтер в аудитории 205",
            "client": client1,
            "category": cat_eq,
            "equipment": printer,
            "manager": None,
            "order_type": Order.OrderType.INCIDENT,
            "priority": Order.Priority.MEDIUM,
            "status": Order.Status.NEW,
            "comment": "При отправке документа на печать мигает красный индикатор, бумага не подаётся.",
        },
        {
            "title": "Нет доступа к корпоративной почте",
            "client": client2,
            "category": cat_acc,
            "equipment": None,
            "manager": ivanov,
            "order_type": Order.OrderType.REQUEST,
            "priority": Order.Priority.HIGH,
            "status": Order.Status.CONFIRMED,
            "comment": "Сменился пароль, не получается войти в webmail. Просьба сбросить пароль.",
        },
        {
            "title": "Ошибка при входе в систему 1С / Деканат",
            "client": client3,
            "category": cat_sw,
            "equipment": pc,
            "manager": petrov,
            "order_type": Order.OrderType.INCIDENT,
            "priority": Order.Priority.MEDIUM,
            "status": Order.Status.PENDING,
            "comment": "Выдаёт сообщение 'Нарушены права доступа к серверу лицензий'. Запросили скриншот у пользователя.",
        },
        {
            "title": "Установка ПО для практических занятий",
            "client": client1,
            "category": cat_sw,
            "equipment": pc,
            "manager": sidorov,
            "order_type": Order.OrderType.SETUP,
            "priority": Order.Priority.LOW,
            "status": Order.Status.CONFIRMED,
            "comment": "Необходимо развернуть Python 3.12 и VS Code на 15 ПК в лаборатории.",
        },
        {
            "title": "Сбои в сети Wi-Fi на 2 этаже",
            "client": client2,
            "category": cat_net,
            "equipment": router,
            "manager": ivanov,
            "order_type": Order.OrderType.INCIDENT,
            "priority": Order.Priority.HIGH,
            "status": Order.Status.PENDING,
            "comment": "Периодически пропадает сигнал Wi-Fi во время лекций.",
        },
        {
            "title": "Доступ к общему сетевому диску",
            "client": client3,
            "category": cat_net,
            "equipment": None,
            "manager": petrov,
            "order_type": Order.OrderType.REQUEST,
            "priority": Order.Priority.LOW,
            "status": Order.Status.COMPLETED,
            "comment": "Подключение сетевой папки '\\fileserver\\study' выполнено успешно, права настроены.",
        },
    ]

    for item in tickets_data:
        order, created = Order.objects.get_or_create(
            title=item["title"],
            defaults=item
        )
        if created and item["status"] == Order.Status.COMPLETED:
            order.complete()

    print(f"Успешно создано {len(tickets_data)} заявок!")
    print("Готово. База данных наполнена всеми данными из PDF!")

if __name__ == "__main__":
    seed()
