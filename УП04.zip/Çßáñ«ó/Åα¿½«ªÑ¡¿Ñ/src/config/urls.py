from django.contrib import admin
from django.urls import path, include
from django.views.generic import RedirectView
from rest_framework_simplejwt.views import TokenObtainPairView, TokenRefreshView

urlpatterns = [
    # Главная страница - редирект на список обращений или дашборд
    path("", RedirectView.as_view(url="/orders/list/", permanent=False)),

    # Админка Django строго по PDF
    path("admin/", admin.site.urls),

    # JWT Авторизация строго по PDF
    path("api/token/", TokenObtainPairView.as_view(), name="token_obtain_pair"),
    path("api/token/refresh/", TokenRefreshView.as_view(), name="token_refresh"),

    # МОДУЛЬ 1: АВТОРИЗАЦИЯ
    path("", include("apps.accounts.urls")),
    path("accounts/login/", RedirectView.as_view(url="/login/", permanent=False)),
    path("accounts/logout/", RedirectView.as_view(url="/logout/", permanent=False)),

    # МОДУЛЬ 2: КАТАЛОГ / СПРАВОЧНИКИ
    path("api/catalog/", include("apps.catalog.urls")),

    # МОДУЛЬ 3: КЛИЕНТЫ
    path("api/clients/", include("apps.clients.urls")),

    # МОДУЛЬ 4: ЗАКАЗЫ / ЗАЯВКИ
    path("orders/", include("apps.orders.urls")),

    # МОДУЛЬ 5: ОТЧЁТЫ
    path("", include("apps.reports.urls")),

    # DRF-вход через браузер (для тестирования) строго по PDF
    path("api/drf-login/", include("rest_framework.urls")),
]
