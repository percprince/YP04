"""Apps package initialization."""
