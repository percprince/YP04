from django.contrib import admin
from .models import Client

@admin.register(Client)
class ClientAdmin(admin.ModelAdmin):
    list_display = ("id", "full_name", "phone", "email", "department", "manager", "created_at")
    search_fields = ("full_name", "phone", "email", "department")
    list_filter = ("manager", "created_at")
