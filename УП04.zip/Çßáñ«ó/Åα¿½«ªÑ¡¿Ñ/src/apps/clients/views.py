from rest_framework import viewsets, filters
from django_filters.rest_framework import DjangoFilterBackend
from .models import Client
from .serializers import ClientSerializer

class ClientViewSet(viewsets.ModelViewSet):
    """CRUD для клиентов / заявителей строго по PDF"""
    queryset = Client.objects.select_related("manager").all()
    serializer_class = ClientSerializer
    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_fields = ["manager", "department"]
    search_fields = ["full_name", "phone", "email", "department"]
    ordering_fields = ["created_at", "full_name"]
