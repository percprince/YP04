from django.db import models
from django.conf import settings

class Client(models.Model):
    """Клиент / Заявитель (пользователь сервиса, преподаватель, сотрудник) строго по PDF"""
    full_name = models.CharField("ФИО заявителя", max_length=150)
    phone = models.CharField("Телефон", max_length=20, unique=True)
    email = models.EmailField("Email", blank=True)
    department = models.CharField("Подразделение / Кабинет", max_length=100, blank=True)
    birth_date = models.DateField("Дата рождения / Трудоустройства", null=True, blank=True)
    manager = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="clients",
        verbose_name="Куратор / Менеджер"
    )
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = "Заявитель"
        verbose_name_plural = "Заявители"
        ordering = ["-created_at"]

    def __str__(self):
        return f"{self.full_name} ({self.phone})"
