"""МОДУЛЬ 3 (КЛИЕНТЫ): Формы создания и редактирования заявителя строго по PDF."""
from django import forms
from .models import Client

class ClientForm(forms.ModelForm):
    """Форма создания / редактирования заявителя"""
    class Meta:
        model = Client
        fields = ["full_name", "phone", "email", "department", "birth_date", "manager"]
        widgets = {
            "full_name": forms.TextInput(attrs={"class": "form-control", "placeholder": "ФИО"}),
            "phone": forms.TextInput(attrs={"class": "form-control", "placeholder": "+7 (999) 000-00-00"}),
            "email": forms.EmailInput(attrs={"class": "form-control", "placeholder": "email@org.ru"}),
            "department": forms.TextInput(attrs={"class": "form-control", "placeholder": "Отдел кадров / Каб. 205"}),
            "birth_date": forms.DateInput(attrs={"class": "form-control", "type": "date"}),
            "manager": forms.Select(attrs={"class": "form-select"}),
        }
