"""МОДУЛЬ 1 (АВТОРИЗАЦИЯ): Формы. Формы для входа и регистрации строго по PDF."""
from django import forms
from django.contrib.auth.forms import AuthenticationForm, UserCreationForm
from .models import User

class LoginForm(AuthenticationForm):
    """Форма входа. Стандартная, но с русскими подписями и Bootstrap классами"""
    username = forms.CharField(
        label="Email или логин",
        widget=forms.TextInput(attrs={"class": "form-control", "placeholder": "Введите email или логин"}),
    )
    password = forms.CharField(
        label="Пароль",
        widget=forms.PasswordInput(attrs={"class": "form-control", "placeholder": "Введите пароль"}),
    )

class RegisterForm(UserCreationForm):
    """Форма регистрации нового сотрудника / заявителя"""
    full_name = forms.CharField(label="ФИО", max_length=150, required=True,
                                widget=forms.TextInput(attrs={"class": "form-control", "placeholder": "Иванов Иван Иванович"}))
    email = forms.EmailField(label="Email", required=True,
                             widget=forms.EmailInput(attrs={"class": "form-control", "placeholder": "user@company.ru"}))
    phone = forms.CharField(label="Телефон", max_length=20, required=False,
                            widget=forms.TextInput(attrs={"class": "form-control", "placeholder": "+7 (999) 000-00-00"}))

    class Meta:
        model = User
        fields = ("username", "full_name", "email", "phone", "role", "position")
        widgets = {
            "username": forms.TextInput(attrs={"class": "form-control"}),
            "role": forms.Select(attrs={"class": "form-select"}),
            "position": forms.TextInput(attrs={"class": "form-control"}),
        }

    def save(self, commit=True):
        user = super().save(commit=False)
        user.full_name = self.cleaned_data.get("full_name", "")
        parts = user.full_name.split(maxsplit=1)
        user.first_name = parts[0] if parts else ""
        user.last_name = parts[1] if len(parts) > 1 else ""
        if commit:
            user.save()
        return user
