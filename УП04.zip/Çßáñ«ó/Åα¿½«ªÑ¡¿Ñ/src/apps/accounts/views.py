from rest_framework import status
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework_simplejwt.tokens import RefreshToken
from django.shortcuts import render, redirect
from django.contrib.auth import login as auth_login, logout as auth_logout
from .serializers import RegisterSerializer, LoginSerializer, UserSerializer
from .forms import LoginForm, RegisterForm

# === API ПРЕДСТАВЛЕНИЯ СТРОГО ПО PDF ===

class RegisterView(APIView):
    """POST /api/auth/register/ - регистрация пользователя"""
    permission_classes = [AllowAny]

    def post(self, request):
        serializer = RegisterSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = serializer.save()

        # Сразу выдаём JWT токены
        refresh = RefreshToken.for_user(user)
        return Response({
            "user": UserSerializer(user).data,
            "access": str(refresh.access_token),
            "refresh": str(refresh),
        }, status=status.HTTP_201_CREATED)

class LoginView(APIView):
    """POST /api/auth/login/ - вход и выдача JWT"""
    permission_classes = [AllowAny]

    def post(self, request):
        serializer = LoginSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = serializer.validated_data["user"]

        refresh = RefreshToken.for_user(user)
        return Response({
            "user": UserSerializer(user).data,
            "access": str(refresh.access_token),
            "refresh": str(refresh),
        })

class MeView(APIView):
    """GET /api/auth/me/ - данные текущего пользователя"""
    permission_classes = [IsAuthenticated]

    def get(self, request):
        return Response(UserSerializer(request.user).data)

# === WEB ПРЕДСТАВЛЕНИЯ ДЛЯ БРАУЗЕРА ===

def web_login(request):
    if request.user.is_authenticated:
        return redirect("/")
    if request.method == "POST":
        form = LoginForm(request, data=request.POST)
        if form.is_valid():
            auth_login(request, form.get_user())
            return redirect(request.GET.get("next", "/"))
    else:
        form = LoginForm()
    return render(request, "login.html", {"form": form})

def web_logout(request):
    auth_logout(request)
    return redirect("/login/")

def web_register(request):
    if request.method == "POST":
        form = RegisterForm(request.POST)
        if form.is_valid():
            user = form.save()
            auth_login(request, user)
            return redirect("/")
    else:
        form = RegisterForm()
    return render(request, "register.html", {"form": form})
