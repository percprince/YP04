from django.urls import path
from rest_framework_simplejwt.views import TokenRefreshView
from . import views

app_name = "accounts"

urlpatterns = [
    # API endpoints строго по PDF
    path("api/auth/register/", views.RegisterView.as_view(), name="api_register"),
    path("api/auth/login/", views.LoginView.as_view(), name="api_login"),
    path("api/auth/me/", views.MeView.as_view(), name="api_me"),
    path("api/auth/token/refresh/", TokenRefreshView.as_view(), name="api_token_refresh"),

    # Веб-страницы для браузера
    path("login/", views.web_login, name="login"),
    path("logout/", views.web_logout, name="logout"),
    path("register/", views.web_register, name="register"),
]
