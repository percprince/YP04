from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import User

@admin.register(User)
class CustomUserAdmin(UserAdmin):
    """Расширяем стандартную админку User строго по PDF"""
    list_display = ("username", "full_name", "email", "role", "position", "is_active", "is_staff")
    list_filter = ("role", "position", "is_active", "is_staff")
    search_fields = ("username", "full_name", "email", "phone")

    fieldsets = UserAdmin.fieldsets + (
        ("Дополнительно", {"fields": ("full_name", "phone", "role", "position")}),
    )
    add_fieldsets = UserAdmin.add_fieldsets + (
        ("Дополнительно", {"fields": ("full_name", "phone", "role", "position")}),
    )
