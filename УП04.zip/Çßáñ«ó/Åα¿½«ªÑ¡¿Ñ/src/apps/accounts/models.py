from django.contrib.auth.models import AbstractUser
from django.db import models

class User(AbstractUser):
    """Кастомный пользователь с ролями и должностью строго по PDF"""
    class Role(models.TextChoices):
        ADMIN = "admin", "Администратор"
        MANAGER = "manager", "Руководитель IT"
        SPECIALIST = "specialist", "Специалист поддержки"
        CLIENT = "client", "Заявитель"

    full_name = models.CharField("ФИО", max_length=255, blank=True)
    phone = models.CharField("Телефон", max_length=20, blank=True)
    role = models.CharField(
        "Роль",
        max_length=32,
        choices=Role.choices,
        default=Role.CLIENT,
    )
    position = models.CharField("Должность", max_length=100, blank=True, default="Сотрудник")

    class Meta:
        verbose_name = "Сотрудник / Пользователь"
        verbose_name_plural = "Сотрудники / Пользователи"

    def __str__(self):
        return f"{self.full_name or self.username} ({self.get_role_display()})"
