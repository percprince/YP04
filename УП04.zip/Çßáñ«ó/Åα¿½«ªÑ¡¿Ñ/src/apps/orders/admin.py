from django.contrib import admin
from .models import Order

@admin.register(Order)
class OrderAdmin(admin.ModelAdmin):
    """Админка заявок строго по PDF"""
    list_display = ("id", "title", "client", "category", "order_type", "priority", "status", "manager", "created_at")
    list_filter = ("status", "order_type", "priority", "category", "created_at")
    search_fields = ("title", "client__full_name", "comment")
    readonly_fields = ("created_at", "completed_at")
