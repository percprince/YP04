"""МОДУЛЬ 4 (ЗАКАЗЫ / ЗАЯВКИ): Формы строго по PDF."""
from django import forms
from .models import Order
from apps.catalog.models import EquipmentItem

class OrderForm(forms.ModelForm):
    """Форма создания и редактирования заявки строго по PDF"""
    class Meta:
        model = Order
        fields = ["title", "client", "category", "equipment", "order_type", "priority", "status", "manager", "comment"]
        widgets = {
            "title": forms.TextInput(attrs={"class": "form-control", "placeholder": "Краткая тема проблемы"}),
            "client": forms.Select(attrs={"class": "form-select"}),
            "category": forms.Select(attrs={"class": "form-select"}),
            "equipment": forms.Select(attrs={"class": "form-select"}),
            "order_type": forms.Select(attrs={"class": "form-select"}),
            "priority": forms.Select(attrs={"class": "form-select"}),
            "status": forms.Select(attrs={"class": "form-select"}),
            "manager": forms.Select(attrs={"class": "form-select"}),
            "comment": forms.Textarea(attrs={"class": "form-control", "rows": 3, "placeholder": "Подробное описание инцидента"}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Фильтруем оборудование: для новых заявок показываем исправное
        if not self.instance.pk:
            self.fields["equipment"].queryset = EquipmentItem.objects.filter(
                status=EquipmentItem.Status.OPERATIONAL
            )
