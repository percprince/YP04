from django.db import models
from django.conf import settings
from django.utils import timezone
from apps.clients.models import Client
from apps.catalog.models import EquipmentItem, Category

class Order(models.Model):
    """Модель заявки / обращения на обслуживание строго по PDF"""
    class OrderType(models.TextChoices):
        INCIDENT = "incident", "Инцидент / Сбой"
        REQUEST = "request", "Запрос на обслуживание"
        SETUP = "setup", "Установка / Настройка"

    class Priority(models.TextChoices):
        LOW = "low", "Низкий"
        MEDIUM = "medium", "Средний"
        HIGH = "high", "Высокий"
        CRITICAL = "critical", "Критический"

    class Status(models.TextChoices):
        NEW = "new", "Новая"
        CONFIRMED = "confirmed", "В работе"
        PENDING = "pending", "Ожидает ответа"
        COMPLETED = "completed", "Решена / Завершена"
        CANCELLED = "cancelled", "Отменена"

    title = models.CharField("Тема обращения", max_length=200)
    client = models.ForeignKey(
        Client,
        on_delete=models.CASCADE,
        related_name="orders",
        verbose_name="Заявитель"
    )
    category = models.ForeignKey(
        Category,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="orders",
        verbose_name="Категория"
    )
    equipment = models.ForeignKey(
        EquipmentItem,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="orders",
        verbose_name="Оборудование / Объект"
    )
    manager = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT,
        null=True,
        blank=True,
        related_name="assigned_orders",
        verbose_name="Ответственный специалист"
    )
    order_type = models.CharField(
        "Тип заявки",
        max_length=20,
        choices=OrderType.choices,
        default=OrderType.INCIDENT
    )
    priority = models.CharField(
        "Приоритет",
        max_length=20,
        choices=Priority.choices,
        default=Priority.MEDIUM
    )
    status = models.CharField(
        "Статус",
        max_length=20,
        choices=Status.choices,
        default=Status.NEW
    )
    comment = models.TextField("Описание проблемы / Решение", blank=True)
    created_at = models.DateTimeField("Создана", auto_now_add=True)
    completed_at = models.DateTimeField("Завершена", null=True, blank=True)

    class Meta:
        verbose_name = "Заявка"
        verbose_name_plural = "Заявки"
        ordering = ["-created_at"]

    def __str__(self):
        return f"Заявка #{self.pk} - {self.title} ({self.client.full_name})"

    def save(self, *args, **kwargs):
        """
        Каскад строго по PDF:
        При создании заявки с оборудованием — переводим оборудование в статус 'На обслуживании'
        """
        is_new = not self.pk
        super().save(*args, **kwargs)

        if is_new and self.equipment:
            if self.equipment.status == EquipmentItem.Status.OPERATIONAL:
                self.equipment.status = EquipmentItem.Status.MAINTENANCE
                self.equipment.save()

    def complete(self):
        """
        Завершить заявку с каскадом строго по PDF:
        Статус = completed, дата = now(), оборудование возвращается в 'В работе'
        """
        self.status = self.Status.COMPLETED
        self.completed_at = timezone.now()
        if self.equipment:
            self.equipment.status = EquipmentItem.Status.OPERATIONAL
            self.equipment.save()
        self.save()

    def cancel(self):
        """
        Отменить заявку, освободить оборудование
        """
        self.status = self.Status.CANCELLED
        if self.equipment:
            self.equipment.status = EquipmentItem.Status.OPERATIONAL
            self.equipment.save()
        self.save()
