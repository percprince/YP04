from rest_framework import serializers
from .models import Order

class OrderSerializer(serializers.ModelSerializer):
    """Сериализатор заявок строго по PDF"""
    client_name = serializers.CharField(source="client.full_name", read_only=True)
    category_name = serializers.CharField(source="category.name", read_only=True)
    equipment_name = serializers.CharField(source="equipment.__str__", read_only=True)
    manager_name = serializers.CharField(source="manager.get_full_name", read_only=True)
    status_display = serializers.CharField(source="get_status_display", read_only=True)
    order_type_display = serializers.CharField(source="get_order_type_display", read_only=True)
    priority_display = serializers.CharField(source="get_priority_display", read_only=True)

    class Meta:
        model = Order
        fields = [
            "id", "title", "client", "client_name", "category", "category_name",
            "equipment", "equipment_name", "manager", "manager_name",
            "order_type", "order_type_display", "priority", "priority_display",
            "status", "status_display", "comment", "created_at", "completed_at"
        ]
        read_only_fields = ["created_at", "completed_at"]
