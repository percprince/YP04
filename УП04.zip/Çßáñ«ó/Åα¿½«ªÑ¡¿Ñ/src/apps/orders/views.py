from rest_framework import viewsets, filters, status
from rest_framework.decorators import action
from rest_framework.response import Response
from django_filters.rest_framework import DjangoFilterBackend
from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from .models import Order
from .serializers import OrderSerializer
from .forms import OrderForm

# === REST API VIEWSET СТРОГО ПО PDF ===

class OrderViewSet(viewsets.ModelViewSet):
    """CRUD для заявок / заказов с фильтрами и действиями завершения"""
    queryset = Order.objects.select_related("client", "category", "equipment", "manager").all()
    serializer_class = OrderSerializer
    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_fields = ["status", "order_type", "priority", "category", "manager", "client"]
    search_fields = ["title", "comment", "client__full_name", "equipment__name"]
    ordering_fields = ["created_at", "priority", "status"]

    @action(detail=True, methods=["post"])
    def complete(self, request, pk=None):
        """POST /api/orders/{id}/complete/ - завершить заявку с каскадом"""
        order = self.get_object()
        order.complete()
        return Response({
            "status": "Заявка успешно завершена",
            "order": OrderSerializer(order).data
        })

    @action(detail=True, methods=["post"])
    def cancel(self, request, pk=None):
        """POST /api/orders/{id}/cancel/ - отменить заявку"""
        order = self.get_object()
        order.cancel()
        return Response({
            "status": "Заявка отменена",
            "order": OrderSerializer(order).data
        })

# === WEB ПРЕДСТАВЛЕНИЯ ДЛЯ БРАУЗЕРА СТРОГО ПО PDF ===

def order_list_view(request):
    """Список всех обращений с фильтрами"""
    orders = Order.objects.select_related("client", "category", "manager").all()
    status_filter = request.GET.get("status")
    priority_filter = request.GET.get("priority")
    search_query = request.GET.get("q")

    if status_filter:
        orders = orders.filter(status=status_filter)
    if priority_filter:
        orders = orders.filter(priority=priority_filter)
    if search_query:
        orders = orders.filter(title__icontains=search_query)

    context = {
        "orders": orders,
        "selected_status": status_filter,
        "selected_priority": priority_filter,
        "search_query": search_query,
        "statuses": Order.Status.choices,
        "priorities": Order.Priority.choices,
    }
    return render(request, "ticket_list.html", context)

@login_required
def order_create_view(request):
    """Создание нового обращения"""
    if request.method == "POST":
        form = OrderForm(request.POST)
        if form.is_valid():
            order = form.save(commit=False)
            if not order.manager and request.user.is_authenticated and request.user.role in ("admin", "specialist"):
                order.manager = request.user
            order.save()
            return redirect("orders:order_detail", pk=order.pk)
    else:
        form = OrderForm()
    return render(request, "ticket_create.html", {"form": form})

def order_detail_view(request, pk):
    """Карточка обращения с возможностью смены статуса"""
    order = get_object_or_404(Order.objects.select_related("client", "category", "equipment", "manager"), pk=pk)
    return render(request, "ticket_detail.html", {"order": order})

@login_required
def order_complete_view(request, pk):
    """Действие завершения заявки из браузера"""
    order = get_object_or_404(Order, pk=pk)
    order.complete()
    return redirect("orders:order_detail", pk=pk)

@login_required
def order_cancel_view(request, pk):
    """Действие отмены заявки из браузера"""
    order = get_object_or_404(Order, pk=pk)
    order.cancel()
    return redirect("orders:order_detail", pk=pk)
