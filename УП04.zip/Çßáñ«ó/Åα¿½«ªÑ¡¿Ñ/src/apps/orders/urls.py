from django.urls import path, include
from rest_framework.routers import DefaultRouter
from . import views

app_name = "orders"

router = DefaultRouter()
router.register("api/orders", views.OrderViewSet, basename="api_orders")

urlpatterns = [
    # API endpoints
    path("", include(router.urls)),

    # Веб-страницы по PDF:
    # path("", views.order_list, name="order_list")
    # path("create/", views.order_create, name="order_create")
    # path("<int:pk>/", views.order_detail, name="order_detail")
    # path("<int:pk>/complete/", views.order_complete, name="order_complete")
    # path("<int:pk>/cancel/", views.order_cancel, name="order_cancel")
    path("list/", views.order_list_view, name="order_list"),
    path("create/", views.order_create_view, name="order_create"),
    path("<int:pk>/", views.order_detail_view, name="order_detail"),
    path("<int:pk>/complete/", views.order_complete_view, name="order_complete"),
    path("<int:pk>/cancel/", views.order_cancel_view, name="order_cancel"),
]
