from django.contrib import admin
from .models import Location, Category, Vendor, EquipmentItem

@admin.register(Location)
class LocationAdmin(admin.ModelAdmin):
    list_display = ("id", "name")
    search_fields = ("name",)

@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ("id", "name", "sla_hours")
    search_fields = ("name",)

@admin.register(Vendor)
class VendorAdmin(admin.ModelAdmin):
    list_display = ("id", "name", "country", "created_at")
    search_fields = ("name",)

@admin.register(EquipmentItem)
class EquipmentItemAdmin(admin.ModelAdmin):
    list_display = ("id", "name", "vendor", "category", "inventory_number", "status")
    list_filter = ("category", "vendor", "status")
    search_fields = ("name", "inventory_number")
    autocomplete_fields = ("vendor", "category")
