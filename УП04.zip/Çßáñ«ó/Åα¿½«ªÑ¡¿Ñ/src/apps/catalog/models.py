from django.db import models

class Location(models.Model):
    """Модель 'Локация' (кабинет, корпус, этаж) строго по ПР3 PDF"""
    name = models.CharField("Название", max_length=255)

    class Meta:
        verbose_name = "Локация"
        verbose_name_plural = "Локации"
        ordering = ["name"]

    def __str__(self):
        return self.name

class Category(models.Model):
    """Модель 'Категория' (Оборудование, ПО, Сеть, Учетные записи и т.д.) строго по PDF"""
    name = models.CharField("Название", max_length=255)
    description = models.TextField("Описание", blank=True)
    sla_hours = models.PositiveIntegerField("Нормативное время решения (SLA, часов)", default=8)

    class Meta:
        verbose_name = "Категория"
        verbose_name_plural = "Категории"
        ordering = ["name"]

    def __str__(self):
        return self.name

class Vendor(models.Model):
    """Модель 'Производитель / Поставщик' строго по ПР3 PDF"""
    name = models.CharField("Название", max_length=255, unique=True)
    country = models.CharField("Страна / Контакт", max_length=100, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = "Производитель"
        verbose_name_plural = "Производители"
        ordering = ["name"]

    def __str__(self):
        return self.name

class EquipmentItem(models.Model):
    """Модель 'Оборудование / Тип инцидента' (Model в ПР3/Car в ПР5)"""
    class Status(models.TextChoices):
        OPERATIONAL = "operational", "В работе"
        MAINTENANCE = "maintenance", "На обслуживании"
        DECOMMISSIONED = "decommissioned", "Списано"

    name = models.CharField("Название / Модель", max_length=255)
    vendor = models.ForeignKey(
        Vendor,
        on_delete=models.PROTECT,
        verbose_name="Производитель",
        related_name="items"
    )
    category = models.ForeignKey(
        Category,
        on_delete=models.PROTECT,
        verbose_name="Категория",
        related_name="items"
    )
    inventory_number = models.CharField("Инвентарный номер / Код", max_length=50, unique=True)
    status = models.CharField(
        "Статус",
        max_length=30,
        choices=Status.choices,
        default=Status.OPERATIONAL
    )
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = "Оборудование / Объект учёта"
        verbose_name_plural = "Оборудование / Объекты учёта"
        ordering = ["-created_at"]

    def __str__(self):
        return f"{self.vendor.name} {self.name} ({self.inventory_number})"
