from django.urls import path, include
from rest_framework.routers import DefaultRouter
from . import views

router = DefaultRouter()
router.register("locations", views.LocationViewSet, basename="locations")
router.register("categories", views.CategoryViewSet, basename="categories")
router.register("vendors", views.VendorViewSet, basename="vendors")
router.register("equipment", views.EquipmentItemViewSet, basename="equipment")

urlpatterns = [
    path("", include(router.urls)),
]
