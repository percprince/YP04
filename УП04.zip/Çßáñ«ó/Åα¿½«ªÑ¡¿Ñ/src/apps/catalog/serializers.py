from rest_framework import serializers
from .models import Location, Category, Vendor, EquipmentItem

class LocationSerializer(serializers.ModelSerializer):
    class Meta:
        model = Location
        fields = ["id", "name"]

class CategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = Category
        fields = ["id", "name", "description", "sla_hours"]

class VendorSerializer(serializers.ModelSerializer):
    class Meta:
        model = Vendor
        fields = ["id", "name", "country", "created_at"]

class EquipmentItemSerializer(serializers.ModelSerializer):
    vendor_name = serializers.CharField(source="vendor.name", read_only=True)
    category_name = serializers.CharField(source="category.name", read_only=True)
    status_display = serializers.CharField(source="get_status_display", read_only=True)

    class Meta:
        model = EquipmentItem
        fields = [
            "id", "name", "vendor", "vendor_name", "category", "category_name",
            "inventory_number", "status", "status_display", "created_at"
        ]
        read_only_fields = ["created_at"]
