from rest_framework import viewsets, filters
from django_filters.rest_framework import DjangoFilterBackend
from .models import Location, Category, Vendor, EquipmentItem
from .serializers import (
    LocationSerializer, CategorySerializer,
    VendorSerializer, EquipmentItemSerializer
)

class LocationViewSet(viewsets.ModelViewSet):
    """CRUD для локаций"""
    queryset = Location.objects.all()
    serializer_class = LocationSerializer
    search_fields = ["name"]

class CategoryViewSet(viewsets.ModelViewSet):
    """CRUD для категорий обращений"""
    queryset = Category.objects.all()
    serializer_class = CategorySerializer
    search_fields = ["name", "description"]

class VendorViewSet(viewsets.ModelViewSet):
    """CRUD для производителей / поставщиков"""
    queryset = Vendor.objects.all()
    serializer_class = VendorSerializer
    search_fields = ["name", "country"]

class EquipmentItemViewSet(viewsets.ModelViewSet):
    """CRUD для оборудования / объектов учёта с фильтрами"""
    queryset = EquipmentItem.objects.select_related("vendor", "category").all()
    serializer_class = EquipmentItemSerializer
    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_fields = ["category", "vendor", "status"]
    search_fields = ["name", "inventory_number", "vendor__name"]
    ordering_fields = ["created_at", "name"]
