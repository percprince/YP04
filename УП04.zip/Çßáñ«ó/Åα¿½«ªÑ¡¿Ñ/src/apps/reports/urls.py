from django.urls import path
from . import views

app_name = "reports"

urlpatterns = [
    # API endpoints строго по PDF
    path("api/reports/kpi/", views.KPIApiView.as_view(), name="kpi"),
    path("api/reports/revenue/", views.OrdersByDayApiView.as_view(), name="revenue_by_day"),
    path("api/reports/top-models/", views.TopCategoriesApiView.as_view(), name="top_models"),
    path("api/reports/manager-load/", views.ManagerLoadApiView.as_view(), name="manager_load"),
    path("api/reports/stock/", views.StatusDistributionApiView.as_view(), name="stock_status"),

    # Веб-дашборд
    path("dashboard/", views.dashboard_view, name="dashboard"),
]
