from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import AllowAny
from django.shortcuts import render
from .services import ReportService

# === API VIEWS СТРОГО ПО PDF ===

class KPIApiView(APIView):
    """GET /api/reports/kpi/?days=30 - Главные KPI"""
    permission_classes = [AllowAny]

    def get(self, request):
        days = int(request.GET.get("days", 30))
        return Response(ReportService.kpi(days))

class OrdersByDayApiView(APIView):
    """GET /api/reports/revenue/ или /api/reports/by-day/"""
    permission_classes = [AllowAny]

    def get(self, request):
        days = int(request.GET.get("days", 30))
        return Response(ReportService.orders_by_day(days))

class TopCategoriesApiView(APIView):
    """GET /api/reports/top-models/ или /api/reports/top-categories/"""
    permission_classes = [AllowAny]

    def get(self, request):
        limit = int(request.GET.get("limit", 5))
        return Response(ReportService.top_categories(limit))

class ManagerLoadApiView(APIView):
    """GET /api/reports/manager-load/ - Загрузка специалистов"""
    permission_classes = [AllowAny]

    def get(self, request):
        days = int(request.GET.get("days", 30))
        return Response(ReportService.manager_load(days))

class StatusDistributionApiView(APIView):
    """GET /api/reports/stock/ - Распределение по статусам"""
    permission_classes = [AllowAny]

    def get(self, request):
        return Response(ReportService.status_distribution())

# === ВЕБ-ДАШБОРД ДЛЯ БРАУЗЕРА ===

def dashboard_view(request):
    """Страница дашборда аналитики"""
    kpi_data = ReportService.kpi(30)
    status_data = ReportService.status_distribution()
    top_categories = ReportService.top_categories(5)
    manager_load = ReportService.manager_load(30)

    context = {
        "kpi": kpi_data,
        "status_distribution": status_data,
        "top_categories": top_categories,
        "manager_load": manager_load,
    }
    return render(request, "kpi_dashboard.html", context)
