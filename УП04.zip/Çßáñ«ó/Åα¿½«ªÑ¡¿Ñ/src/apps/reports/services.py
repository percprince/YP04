from datetime import timedelta
from django.utils import timezone
from django.db.models import Count
from django.db.models.functions import TruncDate
from apps.orders.models import Order
from apps.catalog.models import Category

class ReportService:
    """Сервис аналитики и отчётов строго по PDF"""

    @staticmethod
    def kpi(days: int = 30) -> dict:
        """Главные KPI показатели службы технической поддержки"""
        since = timezone.now() - timedelta(days=days)
        all_orders = Order.objects.filter(created_at__gte=since)

        total_count = all_orders.count()
        completed_count = all_orders.filter(status=Order.Status.COMPLETED).count()
        in_progress_count = all_orders.filter(status=Order.Status.CONFIRMED).count()
        new_count = all_orders.filter(status=Order.Status.NEW).count()
        pending_count = all_orders.filter(status=Order.Status.PENDING).count()

        # Процент решённых заявок
        resolution_rate = round((completed_count / total_count * 100), 1) if total_count > 0 else 100.0

        return {
            "total_orders": total_count,
            "completed_count": completed_count,
            "in_progress_count": in_progress_count,
            "new_count": new_count,
            "pending_count": pending_count,
            "resolution_rate": resolution_rate,
            "period_days": days,
        }

    @staticmethod
    def orders_by_day(days: int = 30) -> list:
        """Количество поступивших заявок по дням (динамика)"""
        since = timezone.now() - timedelta(days=days)
        rows = (
            Order.objects.filter(created_at__gte=since)
            .annotate(date=TruncDate("created_at"))
            .values("date")
            .annotate(count=Count("id"))
            .order_by("date")
        )
        return [{"date": str(r["date"]), "count": r["count"]} for r in rows]

    @staticmethod
    def top_categories(limit: int = 5) -> list:
        """Топ категорий обращений строго по PDF"""
        rows = (
            Order.objects.filter(category__isnull=False)
            .values("category__name")
            .annotate(count=Count("id"))
            .order_by("-count")[:limit]
        )
        return [{"category": r["category__name"], "count": r["count"]} for r in rows]

    @staticmethod
    def manager_load(days: int = 30) -> list:
        """Загрузка специалистов поддержки (заявки в работе и выполненные)"""
        since = timezone.now() - timedelta(days=days)
        rows = (
            Order.objects.filter(created_at__gte=since, manager__isnull=False)
            .values("manager__username", "manager__full_name")
            .annotate(count=Count("id"))
            .order_by("-count")
        )
        return [
            {
                "specialist": r["manager__full_name"] or r["manager__username"],
                "orders_count": r["count"]
            }
            for r in rows
        ]

    @staticmethod
    def status_distribution() -> list:
        """Распределение всех заявок по статусам"""
        rows = Order.objects.values("status").annotate(count=Count("id"))
        status_labels = dict(Order.Status.choices)
        return [
            {
                "status": r["status"],
                "status_display": status_labels.get(r["status"], r["status"]),
                "count": r["count"]
            }
            for r in rows
        ]
