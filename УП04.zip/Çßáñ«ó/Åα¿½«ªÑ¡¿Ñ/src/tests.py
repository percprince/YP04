from django.test import TestCase
from django.contrib.auth import get_user_model
from rest_framework.test import APIClient
from apps.catalog.models import Category, Vendor, EquipmentItem
from apps.clients.models import Client
from apps.orders.models import Order
from apps.reports.services import ReportService

User = get_user_model()

class HelpDeskSystemTests(TestCase):
    """Комплексные тесты всех модулей информационной системы строго по ПР6"""

    def setUp(self):
        self.client_api = APIClient()

        # 1. Пользователь
        self.user = User.objects.create_user(
            username="test_tech",
            password="testpassword123",
            full_name="Тестовый Инженер",
            role=User.Role.SPECIALIST
        )

        # 2. Категория и Производитель
        self.category = Category.objects.create(name="Оборудование", sla_hours=4)
        self.vendor = Vendor.objects.create(name="TestCorp", country="Россия")

        # 3. Оборудование
        self.equipment = EquipmentItem.objects.create(
            name="Принтер HP",
            vendor=self.vendor,
            category=self.category,
            inventory_number="TST-999",
            status=EquipmentItem.Status.OPERATIONAL
        )

        # 4. Заявитель
        self.client_obj = Client.objects.create(
            full_name="Петров Иван",
            phone="+79990001122",
            email="petrov@test.ru",
            department="Каб. 101"
        )

    def test_user_creation_and_role(self):
        """Тест создания пользователя и роли"""
        self.assertEqual(self.user.role, User.Role.SPECIALIST)
        self.assertTrue(self.user.check_password("testpassword123"))

    def test_order_cascade_on_create_and_complete(self):
        """
        Тест каскадной логики строго по PDF:
        - при создании заявки оборудование переходит в 'maintenance'
        - при вызове complete() заявка завершается, а оборудование возвращается в 'operational'
        """
        # Создаем заявку с оборудованием
        order = Order.objects.create(
            title="Замятие бумаги",
            client=self.client_obj,
            category=self.category,
            equipment=self.equipment,
            manager=self.user,
            order_type=Order.OrderType.INCIDENT,
            priority=Order.Priority.HIGH,
            status=Order.Status.NEW
        )

        # Проверяем каскад создания
        self.equipment.refresh_from_db()
        self.assertEqual(self.equipment.status, EquipmentItem.Status.MAINTENANCE)

        # Завершаем заявку
        order.complete()
        order.refresh_from_db()
        self.equipment.refresh_from_db()

        self.assertEqual(order.status, Order.Status.COMPLETED)
        self.assertIsNotNone(order.completed_at)
        self.assertEqual(self.equipment.status, EquipmentItem.Status.OPERATIONAL)

    def test_reports_kpi_service(self):
        """Тест сервиса расчёта KPI службы поддержки"""
        # Создадим заявку
        Order.objects.create(
            title="Сбой сети",
            client=self.client_obj,
            category=self.category,
            status=Order.Status.NEW
        )

        kpi = ReportService.kpi(30)
        self.assertIn("total_orders", kpi)
        self.assertIn("resolution_rate", kpi)
        self.assertGreaterEqual(kpi["total_orders"], 1)

    def test_api_orders_list(self):
        """Тест REST API списка заявок"""
        Order.objects.create(
            title="Тестовая заявка для API",
            client=self.client_obj,
            category=self.category,
            status=Order.Status.NEW
        )
        response = self.client_api.get("/orders/api/orders/")
        self.assertEqual(response.status_code, 200)

    def test_api_kpi_endpoint(self):
        """Тест REST API KPI показателя"""
        response = self.client_api.get("/api/reports/kpi/")
        self.assertEqual(response.status_code, 200)
        self.assertIn("total_orders", response.data)

    def test_web_pages_render(self):
        """Тест рендеринга всех веб-страниц приложения"""
        # Главная страница (редирект на /orders/list/)
        resp = self.client.get("/")
        self.assertIn(resp.status_code, (200, 302))

        # Страница списка заявок
        resp = self.client.get("/orders/list/")
        self.assertEqual(resp.status_code, 200)
        self.assertContains(resp, "Электронная система учёта заявок")

        # Страница входа
        resp = self.client.get("/login/")
        self.assertEqual(resp.status_code, 200)
        self.assertContains(resp, "Авторизация в HelpDesk")

        # Страница регистрации
        resp = self.client.get("/register/")
        self.assertEqual(resp.status_code, 200)
        self.assertContains(resp, "Регистрация в HelpDesk")

        # Страница аналитического дашборда
        resp = self.client.get("/dashboard/")
        self.assertEqual(resp.status_code, 200)
        self.assertContains(resp, "Панель показателей IT-поддержки (KPI)")

    def test_auth_api(self):
        """Тест API аутентификации и выдачи JWT токенов"""
        # Регистрация
        reg_resp = self.client_api.post("/api/auth/register/", {
            "username": "new_specialist",
            "password": "StrongPassword123!",
            "password2": "StrongPassword123!",
            "email": "spec@test.ru",
            "full_name": "Новый Специалист",
            "role": "specialist"
        }, format="json")
        self.assertEqual(reg_resp.status_code, 201)
        self.assertIn("access", reg_resp.data)

        # Вход
        login_resp = self.client_api.post("/api/auth/login/", {
            "username": "new_specialist",
            "password": "StrongPassword123!"
        }, format="json")
        self.assertEqual(login_resp.status_code, 200)
        self.assertIn("access", login_resp.data)

    def test_order_creation_web(self):
        """Тест создания заявки через авторизованную веб-форму"""
        self.client.force_login(self.user)
        resp = self.client.post("/orders/create/", {
            "title": "Проблема с монитором",
            "client": self.client_obj.pk,
            "category": self.category.pk,
            "order_type": "incident",
            "priority": "high",
            "status": "new",
            "comment": "Мерцает экран"
        })
        self.assertEqual(resp.status_code, 302)  # Редирект на детальную страницу
        self.assertTrue(Order.objects.filter(title="Проблема с монитором").exists())
