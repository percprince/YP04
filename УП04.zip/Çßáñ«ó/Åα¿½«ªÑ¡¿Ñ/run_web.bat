echo ===================================================
echo Запуск Django веб-сервера HelpDesk IT...
echo ===================================================
cd src
python manage.py makemigrations
python manage.py migrate
python seed_data.py
echo Сервер доступен по адресу: http://127.0.0.1:8000/
python manage.py runserver 127.0.0.1:8000
pause
