=====================================
echo Запуск Streamlit Дашборда аналитики...
echo ===================================================
cd dashboard_streamlit
python -m streamlit run app.py
pause
